﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'gl', {
	confirmCleanup: 'O texto que quere pegar semella ser copiado desde o Word. Quere depuralo antes de pegalo?',
	error: 'Non foi posíbel depurar os datos pegados por mor dun erro interno',
	title: 'Pegar desde Word',
	toolbar: 'Pegar desde Word'
} );
