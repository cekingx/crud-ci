﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sk', {
	confirmCleanup: 'Zdá sa, že vkladaný text pochádza z programu MS Word. Chcete ho pred vkladaním automaticky vyčistiť?',
	error: 'Kvôli internej chybe nebolo možné vložené dáta vyčistiť',
	title: 'Vložiť z Wordu',
	toolbar: 'Vložiť z Wordu'
} );
