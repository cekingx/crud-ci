﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sl', {
	confirmCleanup: 'Besedilo, ki ga želite prilepiti, je kopirano iz Worda. Ali ga želite očistiti, preden ga prilepite?',
	error: 'Ni bilo mogoče očistiti prilepljenih podatkov zaradi notranje napake',
	title: 'Prilepi iz Worda',
	toolbar: 'Prilepi iz Worda'
} );
