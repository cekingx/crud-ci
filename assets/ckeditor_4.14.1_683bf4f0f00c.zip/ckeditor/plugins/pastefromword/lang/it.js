﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'it', {
	confirmCleanup: 'Il testo da incollare sembra provenire da Word. Desideri pulirlo prima di incollare?',
	error: 'Non è stato possibile eliminare il testo incollato a causa di un errore interno.',
	title: 'Incolla da Word',
	toolbar: 'Incolla da Word'
} );
