﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'bn', {
	options: 'Special Character Options', // MISSING
	title: 'বিশেষ ক্যারেক্টার বাছাই কর',
	toolbar: 'বিশেষ অক্ষর যুক্ত কর'
} );
