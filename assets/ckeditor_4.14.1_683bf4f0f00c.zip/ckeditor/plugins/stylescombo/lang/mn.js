﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'mn', {
	label: 'Загвар',
	panelTitle: 'Загвар хэлбэржүүлэх',
	panelTitle1: 'Block Styles', // MISSING
	panelTitle2: 'Inline Styles', // MISSING
	panelTitle3: 'Object Styles' // MISSING
} );
