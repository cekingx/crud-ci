﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'nl', {
	label: 'Stijl',
	panelTitle: 'Opmaakstijlen',
	panelTitle1: 'Blok stijlen',
	panelTitle2: 'Inline stijlen',
	panelTitle3: 'Object stijlen'
} );
