﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'de', {
	label: 'Stil',
	panelTitle: 'Formatierungsstile',
	panelTitle1: 'Blockstile',
	panelTitle2: 'Inline Stilart',
	panelTitle3: 'Objektstile'
} );
