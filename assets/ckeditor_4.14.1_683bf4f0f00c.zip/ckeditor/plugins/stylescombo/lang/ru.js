﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ru', {
	label: 'Стили',
	panelTitle: 'Стили форматирования',
	panelTitle1: 'Стили блока',
	panelTitle2: 'Стили элемента',
	panelTitle3: 'Стили объекта'
} );
